// backend.js
// Express server for CV analysis using OpenAI GPT
//
// Setup Instructions:
// 1. Ensure this file is named "backend.js" and placed in your project root directory.
// 2. Create a file named ".env" in the same directory with the following content:
//      OPENAI_API_KEY=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
//
// 3. Initialize npm and install dependencies:
//      npm init -y
//      npm install express multer pdf-parse openai dotenv
//
// 4. (Optional) Add a start script to package.json:
//      {
//        "scripts": {
//          "start": "node backend.js"
//        }
//      }
//
// 5. From the project root (where backend.js resides), start the server:
//      node backend.js
//    OR if you added the npm script:
//      npm start
//
// Prevent "MODULE_NOT_FOUND" errors by running the above commands in the directory
// containing this file (use `cd path/to/project` if needed).

import express from 'express';
import multer from 'multer';
import pdfParse from 'pdf-parse';
import OpenAI from 'openai';
import dotenv from 'dotenv';

// Load environment variables from .env file
dotenv.config();

const app = express();
const port = process.env.PORT || 3000;

// Configure OpenAI client
const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY,
});

// Middlewares
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Multer setup for PDF uploads
const upload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: 10 * 1024 * 1024 }, // limit to 10MB
});

/**
 * Build prompt for CV analysis
 * @param {Object} cvData - Fields from form or parsed PDF content
 * @returns {string}
 */
function buildCVPrompt(cvData) {
  const { name, education, experience, skills, raw_text } = cvData;
  let prompt = `Analyze the following CV for an apprenticeship position and provide detailed feedback:

`;
  if (raw_text) {
    prompt += `Full CV Text:
"""
${raw_text}
"""

`;
  } else {
    prompt += `Background:
- Name: ${name || 'N/A'}
- Education: ${education || 'N/A'}
- Experience: ${experience || 'N/A'}
- Skills: ${skills || 'N/A'}

`;
  }
  prompt += `Please provide feedback on:
1. CV Structure and Clarity
2. Relevance of experience for apprenticeship positions
3. Skills assessment
4. Suggested improvements
5. Potential apprenticeship roles that would be a good fit

Format the response in clear sections with actionable recommendations.`;
  return prompt;
}

/**
 * Analyze CV text with OpenAI
 */
async function analyzeWithOpenAI(prompt) {
  const completion = await openai.chat.completions.create({
    model: 'gpt-4o-mini',
    messages: [{ role: 'user', content: prompt }],
  });
  return completion.choices?.[0]?.message?.content || '';
}

/**
 * Endpoint: Analyze CV from form fields or PDF upload
 */
app.post('/api/analyze-cv', upload.single('file'), async (req, res) => {
  try {
    let cvData = {};

    if (req.file) {
      // Parse PDF buffer
      const pdfData = await pdfParse(req.file.buffer);
      cvData.raw_text = pdfData.text;
    } else {
      // Collect form fields
      cvData = {
        name: req.body.name,
        education: req.body.education,
        experience: req.body.experience,
        skills: req.body.skills,
      };
    }

    const prompt = buildCVPrompt(cvData);
    const analysis = await analyzeWithOpenAI(prompt);
    return res.json({ analysis, timestamp: new Date().toISOString() });
  } catch (error) {
    console.error('Error in /api/analyze-cv:', error);
    return res.status(500).json({ error: 'Internal server error' });
  }
});

// Health check
app.get('/health', (_req, res) => {
  res.send({ status: 'ok' });
});

// Start server
app.listen(port, () => {
  console.log(`CV analysis server listening on port ${port}`);
});
