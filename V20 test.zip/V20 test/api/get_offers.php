<?php
// get_offers.php
// Renvoie la liste des offres (JSON)

require 'config.php';

$pdo = getPDO();
$stmt = $pdo->query(
    'SELECT id, company, position, description, requirements, created_at
     FROM offers
     ORDER BY created_at DESC'
);
$offers = $stmt->fetchAll();

header('Content-Type: application/json');
echo json_encode($offers);
?>
