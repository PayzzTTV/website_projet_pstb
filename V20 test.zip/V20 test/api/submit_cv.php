<?php
// submit_cv.php
// Enregistre un CV envoyé en multipart/form-data

require 'config.php';

$name      = trim($_POST['name']      ?? '');
$education = trim($_POST['education'] ?? '');
$experience= trim($_POST['experience']?? '');
$skills    = trim($_POST['skills']    ?? '');

$pdfPath = null;
if (!empty($_FILES['file']['tmp_name']) && $_FILES['file']['error'] === UPLOAD_ERR_OK) {
    $uploadDir = __DIR__ . '/uploads/';
    if (!is_dir($uploadDir)) {
        mkdir($uploadDir, 0755, true);
    }
    $filename = uniqid('cv_') . '_' . basename($_FILES['file']['name']);
    $target   = $uploadDir . $filename;
    move_uploaded_file($_FILES['file']['tmp_name'], $target);
    $pdfPath = 'uploads/' . $filename;
}

$pdo = getPDO();
$stmt = $pdo->prepare(
    'INSERT INTO cvs (name, education, experience, skills, pdf_path)
     VALUES (:name, :education, :experience, :skills, :pdf_path)'
);
$stmt->execute([
    ':name'       => $name,
    ':education'  => $education,
    ':experience' => $experience,
    ':skills'     => $skills,
    ':pdf_path'   => $pdfPath
]);

echo json_encode([
    'success' => true,
    'cv_id'   => $pdo->lastInsertId()
]);
?>
