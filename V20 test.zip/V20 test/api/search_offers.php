<?php
// search_offers.php
// Recherche d'offres par mot‑clé (paramètre GET "q")

require 'config.php';

$term = trim($_GET['q'] ?? '');

$pdo = getPDO();
if ($term !== '') {
    $stmt = $pdo->prepare(
        'SELECT * FROM offers
         WHERE position     LIKE :like
            OR company      LIKE :like
            OR description  LIKE :like
         ORDER BY created_at DESC'
    );
    $like = "%{$term}%";
    $stmt->execute([':like' => $like]);
} else {
    $stmt = $pdo->query('SELECT * FROM offers ORDER BY created_at DESC');
}
$offers = $stmt->fetchAll();

header('Content-Type: application/json');
echo json_encode($offers);
?>
