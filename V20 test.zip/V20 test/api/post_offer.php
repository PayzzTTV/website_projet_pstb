<?php
// post_offer.php
// Enregistre une offre reçue au format JSON

require 'config.php';

$data = json_decode(file_get_contents('php://input'), true);
$company      = trim($data['company']      ?? '');
$position     = trim($data['position']     ?? '');
$description  = trim($data['description']  ?? '');
$requirements = trim($data['requirements'] ?? '');

if (!$company || !$position) {
    http_response_code(400);
    echo json_encode(['error' => 'Champs manquants']);
    exit;
}

$pdo = getPDO();
$stmt = $pdo->prepare(
    'INSERT INTO offers (company, position, description, requirements)
     VALUES (:company, :position, :description, :requirements)'
);
$stmt->execute([
    ':company'      => $company,
    ':position'     => $position,
    ':description'  => $description,
    ':requirements' => $requirements
]);

echo json_encode([
    'success'  => true,
    'offer_id' => $pdo->lastInsertId()
]);
?>
